﻿namespace WithoutGenerics
{
    public class Memo
    {
        public string Contents { get; set; }
    }
}