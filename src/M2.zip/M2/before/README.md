# Module 2

Welcome!

In this module we started from scratch, so there is nothing in this "before" folder.

You'll find the completed code in the "after" folder.

Look for the latest code on GitHub:

https://github.com/ardalis/CSharpGenerics

Thanks!

Steve "ardalis" Smith

Find or Connect with me:

- [ardalis.com](https://ardalis.com)
- [twitter](https://twitter.com/ardalis)
- [github](https://github.com/ardalis)
- [youtube](https://youtube.com/ardalis)
- [mentoring and coaching](https://nimblepros.com)
- [linkedin](https://www.linkedin.com/in/stevenandrewsmith/)
